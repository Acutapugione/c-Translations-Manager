﻿using System;
using System.Collections.Generic;
using TranslationReferenceBooks;

namespace TranslationReferenceBooksTester
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                //TranslationContainer tc = new("England", "Russian");

                //Console.WriteLine($"{tc.Type.fromlanguage} - {tc.Type.targetlanguage}");

                //TryAddTranslationTest();
                //TryAddTargetWordTest();
                //TryReplaceTargetWordTest();
                //TryAddTranslationItemTest();
                //TryAddTranslationItemTest2();
                //TryReplaceTranslationTest();
                //TryRemoveTargetWordTest();
                TryRemoveTranslateTest();
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static TranslationContainer GetTestingObject()
        {
            var element = new Dictionary<string, List<string>>();
            element.Add("Hello", new() { "Привет", "Приветик", "Здравствуй" });
            element.Add("Window", new() { "Окно" });
            element.Add("Show", new() { "Шоу", "Показ", "Представление", "Эстрада" });
            TranslationContainer tc = new("eng", "rus");
            tc.TranslationDict.TryAddTranslationItem(element);
            return tc;
        }
        public static void TryAddTranslationItemTest()
        {
            TranslationContainer obj = GetTestingObject();
            Dictionary<string, List<string>> item = new();
            List<string> tmpList = new List<string>();

            tmpList.Add("Привет");
            tmpList.Add("Здравствуйте");
            tmpList.Add("Здоров");
            tmpList.Add("Приветули");

            item.Add("Hello", tmpList);

            Console.WriteLine($"{obj.TranslationDict.TryAddTranslationItem(item)}");

            Console.WriteLine(obj.TranslationDict.ToString());
        }
        public static void TryAddTranslationItemTest2()
        {
            TranslationContainer obj = GetTestingObject();

            TranslationDict translationDict = new();
            translationDict.TryAddTranslation("Hello", "Привет");
            translationDict.TryAddTranslation("Hello", "Здравствуй");


            TranslationDict translationDict2 = new("eng", "rus", translationDict.Translation_items);
            
            translationDict2.TryAddTranslation("Hi", "Здоров");
            translationDict2.TryAddTranslation("Hi", "Приветули");

            Console.WriteLine($"{obj.TranslationDict.TryAddTranslationItem(translationDict)}");
            Console.WriteLine($"{obj.TranslationDict.TryAddTranslationItem(translationDict2)}");

            Console.WriteLine(obj.TranslationDict.ToString());
        }
        public static void TryAddTranslationTest()
        {
            TranslationContainer obj = GetTestingObject();

            Console.WriteLine($"{obj.TranslationDict.TryAddTranslation("Hello", "Привет")}");

            Console.WriteLine($"{obj.TranslationDict.TryAddTranslation("Hello", "Привет")}");
        }
        public static void TryAddTargetWordTest()
        {
            TranslationContainer obj = GetTestingObject();

            Console.WriteLine($"{obj.TranslationDict.TryAddTargetWord("Hello")}");

            Console.WriteLine($"{obj.TranslationDict.TryAddTargetWord("Hello")}");
        }
        public static void TryReplaceTargetWordTest()
        {
            TranslationContainer obj = GetTestingObject();

            Console.WriteLine($"{obj.TranslationDict.TryReplaceTargetWord("Hello", "Hi")}");

            Console.WriteLine($"{obj.TranslationDict.TryAddTargetWord("Hello")}");

            Console.WriteLine($"{obj.TranslationDict.TryReplaceTargetWord("Hello", "Hi")}");
        }
        public static void TryReplaceTranslationTest()
        {
            TranslationContainer obj = GetTestingObject();

            Console.WriteLine(obj.TranslationDict.ToString());

            Console.WriteLine(obj.TranslationDict.TryReplaceTranslation("Hello", "Приветули", "Привет")); 
            Console.WriteLine(obj.TranslationDict.TryReplaceTranslation("HOllo", "Приветули", "Привет")); 
            Console.WriteLine(obj.TranslationDict.TryReplaceTranslation("Hello", "Приветики", "Привет")); 

            Console.WriteLine(obj.TranslationDict.ToString());
        }
        public static void TryRemoveTargetWordTest()
        {
            TranslationContainer obj = GetTestingObject();
            Console.WriteLine(obj.TranslationDict.ToString());

            Console.WriteLine(obj.TranslationDict.TryRemoveTargetWord("Hello"));
            Console.WriteLine(obj.TranslationDict.ToString());
        }
        public static void TryRemoveTranslateTest()
        {
            TranslationContainer obj = GetTestingObject();
            Console.WriteLine(obj.TranslationDict.ToString());

            Console.WriteLine(obj.TranslationDict.TryRemoveTranslate("Hello", "Привет"));
            Console.WriteLine(obj.TranslationDict.TryRemoveTranslate("Hello", "Приветик"));

            Console.WriteLine(obj.TranslationDict.TryRemoveTranslate("Hello", "Привет"));
            Console.WriteLine(obj.TranslationDict.TryRemoveTranslate("Hello", "Здравствуй"));

            Console.WriteLine(obj.TranslationDict.ToString());
        }
    }
}

