﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MenuManagerModule;
using TranslationReferenceBooks;

namespace TranslationDictManagerTest
{
    class Program
    {
        static async Task Main(string[] args)
        {
            
            await MenuManager.MainMenuInit();
            /*MenuManager.Start();

           await MainMenuHandleAsync(MainMenuPoints.Load);
           Console.WriteLine(TranslationDictManager.ToString());


           TranslationDict translationDict = new TranslationDict( new Dictionary<string, List<string>>() , new TranslationType("eng", "rus"));
           TranslationDictManager.AddTranslationDict(translationDict);

           Console.WriteLine(TranslationDictManager.ToString());

           var translation = TranslationDictManager.Find(new TranslationType("eng", "rus"));
           Console.WriteLine(translation.ToString());
           Console.WriteLine( translation?.TryAddTranslation("Hello", new List<string>() { "Привет", "Приветик", "Здравствуй" }));

           Console.WriteLine(TranslationDictManager.ToString());

           translation?.TryAddTranslation("Phone", "Телефон", "Звонок", "Позвонить" );

           Console.WriteLine(TranslationDictManager.ToString());

           TranslationDictManager.AddTranslationDict("rus", "eng");
           TranslationDictManager.AddTranslationDict("ger", "eng");

           Console.WriteLine(TranslationDictManager.ToString());

           await MainMenuHandleAsync(MainMenuPoints.Save);
            */
        }
    }
}
